package com.example.groceryapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
